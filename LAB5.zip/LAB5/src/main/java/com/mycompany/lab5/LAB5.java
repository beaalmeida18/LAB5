/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab5;

/**
 *
 * @author Usuario
 */
public class LAB5 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
